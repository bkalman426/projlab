public interface ModelObserver {

    public void onModelUpdate();
}
